#include "core/math/RigMath.h"
#include <cstdio>
int main()
{
    const char* e = core::rm::selfTest();
    std::printf("  %-62s %s\n", "core::rm::selfTest", *e ? e : "PASS");
    return *e ? 1 : 0;
}
