#include "conformance/tests/Check.h"
#include "core/types/Clip.h"
#include "core/types/Geometry.h"
#include "core/types/Skeleton.h"
using chk::check; using chk::near;
#include "games/fox/adapt/FoxAdapt.h"
// ── FOX ─────────────────────────────────────────────────────────────────────────────────────────
#include "fox/FmdlFile.h"                 // fox/src

void testFox()
{
    printf("\nFOX FmdlFile -> core::Geometry\n");
    QVector<fox::FmdlMeshGroup> groups(3);
    groups[0].name = QStringLiteral("root");   groups[0].parentIndex = -1; groups[0].visible = true;  groups[0].nameHash32 = 10;
    groups[1].name = QStringLiteral("pouch");  groups[1].parentIndex = 0;  groups[1].visible = false; groups[1].nameHash32 = 11;  // shipped hidden
    groups[2].name = QStringLiteral("strap");  groups[2].parentIndex = 1;  groups[2].visible = true;  groups[2].nameHash32 = 12;  // child of a hidden group

    QVector<fox::FmdlMaterialInstance> mats(2);
    mats[0].name = QStringLiteral("body_mat");
    mats[1].name = QStringLiteral("cloth_mat");

    auto makeMesh = [](int group, int material, int nv, quint16 paletteBase) {
        fox::FmdlMesh m;
        m.meshGroupIndex = group;
        m.materialInstanceIndex = material;
        for (int i = 0; i < nv; ++i) {
            m.positions << float(i) << float(i*2) << 0.0f;
            m.normals   << 0.0f << 1.0f << 0.0f;
            m.uv0       << float(i) * 0.1f << 0.5f;
            m.tangents  << 1.0f << 0.0f << 0.0f << -1.0f;
            m.boneIndices << 0 << 1 << 0 << 0;          // palette-RELATIVE
            m.boneWeights << 0.6f << 0.4f << 0.0f << 0.0f;
        }
        m.palette << paletteBase << quint16(paletteBase + 1);
        for (int i = 0; i + 2 < nv; ++i) { m.triangles << quint16(i) << quint16(i+1) << quint16(i+2); }
        return m;
    };
    QVector<fox::FmdlMesh> meshes;
    meshes << makeMesh(0, 0, 3, 300)      // palette maps to bones 300/301 — above the u8 range
           << makeMesh(2, 1, 4, 5);

    const core::Geometry c = foxadapt::toCore(meshes, groups, mats, 2.04f);
    check(c.vertices.size() == 7, "SoA meshes flattened into one interleaved buffer");
    check(c.parts.size() == 2, "one core::Part per FMDL mesh");
    check(c.triangleCount() == 3, "triangle count preserved (1 + 2)");
    check(c.parts[1].indexStart == 3 && c.indices[3] == 3, "second mesh's u16 indices widened and rebased");
    check(c.hasTangent && c.skinned, "tangent and skinning detected from the data present");
    // Conversion 2 — the silent one.
    check(c.vertices[0].joints[0] == 300 && c.vertices[0].joints[1] == 301,
          "palette-relative bone indices resolved to GLOBAL skeleton indices");
    check(c.vertices[3].joints[0] == 5, "the second mesh uses its OWN palette, not the first's");
    check(near(c.vertices[0].weights[0], 0.6f), "bone weights carried");
    check(c.groups.size() == 3 && c.groups[2].parent == 1, "the mesh-group tree survives as a tree");
    check(c.parts[0].visible, "a mesh under a visible group is shown");
    check(!c.parts[1].visible, "a mesh whose ANCESTOR ships hidden is hidden (inherited visibility)");
    check(c.parts[0].name == QStringLiteral("root") && c.parts[1].name == QStringLiteral("strap"),
          "parts take their group's name");
    check(c.materialNames.size() == 2 && c.parts[1].materialIndex == 1, "material roster and per-part index");

    QVector<fox::FmdlBone> bones(2);
    bones[0].name = QStringLiteral("hip");  bones[0].parentIndex = -1; bones[0].hash32 = 0xAA;
    bones[0].localPos[0] = 0; bones[0].localPos[1] = 1; bones[0].localPos[2] = 0;
    bones[0].worldPos[0] = 0; bones[0].worldPos[1] = 1; bones[0].worldPos[2] = 0;
    bones[1].name = QStringLiteral("spine"); bones[1].parentIndex = 0; bones[1].hash32 = 0xBB;
    bones[1].localPos[1] = 2; bones[1].worldPos[1] = 3;

    const core::Skeleton s = foxadapt::skeletonToCore(bones);
    check(s.size() == 2 && s.parentsPrecedeChildren(), "joint count and parent order");
    check(s.joints[1].nameHash == 0xBB, "StrCode32 name hash carried");
    check(near(s.joints[1].restT[1], 2.0f), "translation-only bind pose carried as restT");
    check(near(s.joints[1].restQ[3], 1.0f) && near(s.joints[1].restQ[0], 0.0f),
          "no rotation invented for a translation-only rig (restQ stays identity)");
    check(near(s.joints[1].inverseBind[13], -3.0f), "inverse bind is translate(-worldPos), as Fox's own exporter does");
}

