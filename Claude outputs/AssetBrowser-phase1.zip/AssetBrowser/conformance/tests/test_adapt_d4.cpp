#include "conformance/tests/Check.h"
#include "core/types/Clip.h"
#include "core/types/Geometry.h"
#include "core/types/Skeleton.h"
using chk::check; using chk::near;
#include "games/d4/adapt/D4Adapt.h"
// ── D4 ──────────────────────────────────────────────────────────────────────────────────────────
#include "model/ModelGeometry.h"          // d4/src

void testD4()
{
    printf("\nD4 ModelGeometry -> core::Geometry\n");
    ::ModelGeometry g;
    g.valid = true;
    g.droppedSubObjects = 2;
    g.droppedVerts = 7;

    // Two primitives with their OWN vertex arrays and primitive-local indices — the thing the
    // shared-buffer conversion has to get right.
    for (int p = 0; p < 2; ++p) {
        ::MeshPrimitive prim;
        prim.materialName   = p ? QStringLiteral("mat_b") : QStringLiteral("mat_a");
        prim.materialIndex  = p;
        prim.subObjectHash  = 0x1000u + p;
        prim.slotHash       = 0x2000u + p;
        prim.doubleSided    = (p == 1);
        for (int i = 0; i < 3; ++i) {
            ::MeshVertex v;
            v.px = float(i + p*10); v.py = float(i); v.pz = float(p);
            v.nx = 0; v.ny = 1; v.nz = 0;
            v.hasColor = true; v.cr = 1.0f; v.cg = 0.5f; v.cb = 0.0f; v.ca = 1.0f;
            v.hasUv1 = true; v.u1 = 0.25f; v.v1 = 0.75f;
            v.joints[0] = quint16(300 + i);          // > 255: the u8 trap POE2 has, D4 does not
            v.weights[0] = 1.0f;
            prim.vertices.append(v);
        }
        prim.indices = { 0, 1, 2 };                  // LOCAL to this primitive
        g.primitives.append(prim);
    }

    // A rig whose rest TRS is D4-native Z-up, with a child listed BEFORE its parent.
    {
        ::ModelJoint child;  child.name = QStringLiteral("child");  child.nameHash = 2; child.parent = 1;
        child.restT = {{0, 4, 0}};                    // +4 on D4's Y → should land on core's -Z
        child.restQ = {{0, 0, 0, 1}};
        child.cloth = true;
        ::ModelJoint root;   root.name = QStringLiteral("root");    root.nameHash = 1; root.parent = -1;
        root.restT = {{1, 2, 3}};
        g.skeleton = { child, root };                 // deliberately out of order
        g.nBaseBones = 1;
    }
    { ::ModelHardpoint h; h.name = QStringLiteral("HP_rightWeapon"); h.boneIndex = 1; h.boneHash = 1;
      h.t = {{0, 5, 0}}; h.q = {{0,0,0,1}}; g.hardpoints.append(h); }

    const core::Geometry c = d4adapt::toCore(g);
    check(c.vertices.size() == 6, "both primitives' vertices land in one buffer");
    check(c.parts.size() == 2, "one core::Part per primitive");
    check(c.triangleCount() == 2, "triangle count preserved (2)");
    // The conversion that silently corrupts a model if it is wrong.
    check(c.parts[1].indexStart == 3 && c.indices[3] == 3 && c.indices[4] == 4 && c.indices[5] == 5,
          "second primitive's local indices rebased onto the shared buffer");
    check(c.parts[0].indexStart == 0 && c.indices[0] == 0, "first primitive's indices unchanged");
    check(c.parts[1].doubleSided && !c.parts[0].doubleSided, "per-part doubleSided preserved");
    check(c.parts[0].slotHash == 0x2000u && c.parts[1].nameHash == 0x1001u, "slot and name hashes preserved");
    check(c.hasColor && c.hasUv1 && !c.hasTangent, "attribute flags: colour and uv1 yes, tangent no");
    check(c.vertices[0].color[1] == 128, "COLOR_0 float 0.5 -> u8 128");
    check(c.vertices[0].joints[0] == 300, "a joint index above 255 survives (u16)");
    check(c.droppedParts == 2 && c.droppedVerts == 7, "the incomplete-mesh counters are carried, not dropped");
    check(near(c.bboxMax[0], 12.0f) && near(c.bboxMin[0], 0.0f), "bounds computed over the merged buffer");

    const core::Skeleton s = d4adapt::skeletonToCore(g);
    check(s.size() == 2, "joint count preserved");
    check(s.parentsPrecedeChildren(), "parents precede children after the sort (input was reversed)");
    check(s.joints[0].name == QStringLiteral("root"), "the root sorted to index 0");
    check(s.joints[1].parent == 0, "the child's parent index was remapped by the sort");
    check(s.joints[1].cloth, "the cloth marker followed its joint through the sort");
    check(s.nBaseBones == 1, "nBaseBones carried");
    // Z-up (x,y,z) -> Y-up (x,z,-y): D4's +4 on Y must become -4 on core's Z.
    check(near(s.joints[1].restT[0], 0) && near(s.joints[1].restT[1], 0) && near(s.joints[1].restT[2], -4),
          "rest translation swapped Z-up -> Y-up (0,4,0) -> (0,0,-4)");

    // swapTRS (D4's proven code) must agree with the independent matrix conjugation.
    {
        const float q[4] = {0.2f, -0.3f, 0.5f, 0.78740079f}, t[3] = {1, 2, 3}, sc[3] = {1, 1, 1};
        float q2[4], t2[3], s2[3];
        d4adapt::swapZUpToYUp(q, t, sc, q2, t2, s2);
        const core::rm::Mat4 viaSwap = core::rm::composeTRS(t2, q2, s2);
        const core::rm::Mat4 native  = core::rm::composeTRS(t, q, sc);
        const core::rm::Mat4 viaConj = core::rm::reframe(native, core::rm::kZUpToYUp);
        bool same = true;
        for (int i = 0; i < 16; ++i) if (!near(viaSwap[i], viaConj[i], 1e-3f)) same = false;
        check(same, "D4's swapTRS == the S-inverse * L * S conjugation (two derivations agree)");
    }

    const QVector<core::Hardpoint> hp = d4adapt::hardpointsToCore(g);
    check(hp.size() == 1 && near(hp[0].t[2], -5.0f), "hardpoint translation swapped to the core frame");
    check(hp[0].modelSpace, "an authored (non-identity) hardpoint is flagged model-space");
}

