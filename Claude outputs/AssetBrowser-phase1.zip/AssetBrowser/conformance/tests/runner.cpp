// One test binary per game. Not a convenience: d4/src/model/ModelGeometry.h and
// poe2/src/model/ModelGeometry.h BOTH declare `struct ModelGeometry`, `MeshVertex` and
// `ModelJoint` in the GLOBAL namespace with different layouts, so linking two games' adapters into
// one program is an ODR violation — it built, ran most of the way, and then segfaulted. That is
// the concrete case for the plan's rule that core headers get a `core/` prefix and each game is
// its own executable.
#include "conformance/tests/Check.h"
#include <QCoreApplication>
void TEST_FN();
int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);
    TEST_FN();
    std::printf("\n%s: %s\n", TEST_NAME, chk::fails ? "FAILURES" : "all pass");
    return chk::fails ? 1 : 0;
}
