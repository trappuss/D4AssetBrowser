// Proves the six elements of the template §2 index shape actually behave, in particular the one
// that cost FOX a real bug: a superseded build must install NOTHING.
#include "core/store/BackgroundIndex.h"
#include <QCoreApplication>
#include <QEventLoop>
#include <QThread>
#include <QTimer>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <thread>

using namespace std::chrono_literals;

class FakeIndex : public core::BackgroundIndex {
public:
    std::atomic<int> builds{0}, installs{0}, cacheLoads{0};
    std::atomic<bool> sawCancelled{false};
    std::atomic<int> payload{0};          // what the build produced
    int              installed = -1;      // what install() published
    bool             cacheHit = false;
    int              buildMs = 50;

protected:
    bool build(const std::function<void(const QString&)>& rep, const std::function<bool()>& cancelled) override
    {
        const int id = ++builds;
        for (int i = 0; i < 10; ++i) {
            std::this_thread::sleep_for(std::chrono::milliseconds(buildMs / 10));
            if (cancelled()) { sawCancelled.store(true); return false; }
        }
        rep(QStringLiteral("built %1").arg(id));
        payload.store(id);
        return true;
    }
    void install() override { ++installs; installed = payload.load(); }
    bool loadCache() override { ++cacheLoads; return cacheHit; }
};

static int fails = 0;
static void check(bool ok, const char* what) { printf("%-58s %s\n", what, ok ? "PASS" : "FAIL"); if (!ok) ++fails; }
static void pump(int ms) { QTimer t; QEventLoop l; QObject::connect(&t, &QTimer::timeout, &l, &QEventLoop::quit); t.start(ms); l.exec(); }

int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);

    // 1. Plain build: ready goes true once, install runs once, on the OWNER thread.
    {
        FakeIndex ix;
        int readyEvents = 0;
        const auto ownerThread = QThread::currentThread();
        QThread* installThread = nullptr;
        QObject::connect(&ix, &core::BackgroundIndex::readyChanged, [&](bool r) { if (r) { ++readyEvents; installThread = QThread::currentThread(); } });
        ix.setFingerprint(QStringLiteral("fp1"));
        ix.start();
        check(!ix.isReady(), "not ready while building");
        pump(300);
        check(ix.isReady(), "ready after the build");
        check(readyEvents == 1, "readyChanged(true) emitted exactly once");
        check(ix.installs == 1, "install() ran once");
        check(installThread == ownerThread, "install() ran on the owner thread, not the worker");
        check(ix.installGeneration() == 1, "installGeneration bumped on install, not on request");
    }

    // 2. THE SCAR: a fingerprint change mid-build supersedes it. The stale build must not install.
    {
        FakeIndex ix;
        ix.buildMs = 400;
        ix.setFingerprint(QStringLiteral("fpA"));
        ix.start();
        pump(60);                                     // build is in flight
        ix.setFingerprint(QStringLiteral("fpB"));     // data changed under it → reset()
        check(!ix.isReady(), "reset() clears ready immediately");
        pump(600);
        check(ix.installs == 0, "a superseded build installs NOTHING");
        check(ix.sawCancelled.load(), "the worker saw cancelled() and abandoned its loop");
        check(ix.installGeneration() == 0, "installGeneration untouched by a superseded build");
        ix.start();                                   // rebuild against the new fingerprint
        pump(700);
        check(ix.installs == 1 && ix.isReady(), "the rebuild installs and becomes ready");
    }

    // 3. A signed cache hit skips the worker entirely.
    {
        FakeIndex ix;
        ix.cacheHit = true;
        ix.setFingerprint(QStringLiteral("fp2"));
        ix.start();
        check(ix.isReady(), "a cache hit is ready synchronously");
        check(ix.builds == 0, "a cache hit does not start a build");
        check(ix.cacheLoads == 1, "loadCache() consulted exactly once");
    }

    // 4. Re-setting the SAME fingerprint is not a change and must not reset a ready index.
    {
        FakeIndex ix;
        ix.cacheHit = true;
        ix.setFingerprint(QStringLiteral("same"));
        ix.start();
        check(ix.isReady(), "ready before the no-op fingerprint set");
        ix.setFingerprint(QStringLiteral("same"));
        check(ix.isReady(), "an unchanged fingerprint does not reset the index");
    }

    printf("\n%s\n", fails ? "BackgroundIndex: FAILURES" : "BackgroundIndex: all pass");
    return fails ? 1 : 0;
}
