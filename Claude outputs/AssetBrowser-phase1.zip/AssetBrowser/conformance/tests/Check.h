#pragma once
#include <cmath>
#include <cstdio>
namespace chk {
inline int fails = 0;
inline void check(bool ok, const char* what) { std::printf("  %-62s %s\n", what, ok ? "PASS" : "FAIL"); if (!ok) ++fails; }
inline bool near(float a, float b, float e = 1e-4f) { return std::fabs(a-b) <= e; }
}
