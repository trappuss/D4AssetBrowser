#include "conformance/tests/Check.h"
#include "core/types/Clip.h"
#include "core/types/Geometry.h"
#include "core/types/Skeleton.h"
#include "games/poe2/adapt/Poe2Adapt.h"
#include "model/AstSkeleton.h"
#include "model/ModelGeometry.h"
using chk::check; using chk::near;

void testPoe2()
{
    printf("\nPOE2 ModelGeometry -> core::Geometry\n");
    ::ModelGeometry g;
    g.sourcePath    = QStringLiteral("art/models/x.smd");
    g.formatVersion = 2;
    g.vertexFormat  = 0x3c | 0x01 | 0x02;   // nrm+tan | uv | joints | uv2 | colour (authored flags)
    g.skinned       = true;
    g.materialPaths = { QStringLiteral("a.mat"), QStringLiteral("b.mat") };

    for (int i = 0; i < 6; ++i) {
        ::MeshVertex v;
        v.px = float(i); v.py = 1.0f; v.pz = 2.0f;       // native Z-down
        v.nx = 0; v.ny = 0; v.nz = 1;
        v.tx = 1; v.ty = 0; v.tz = 0; v.tw = -1;
        v.u = 0.5f; v.v = 0.25f; v.u2 = 0.1f; v.v2 = 0.2f;
        v.color[0] = 10; v.color[1] = 20; v.color[2] = 30; v.color[3] = 255;
        v.joints[0] = uint8_t(i); v.weights[0] = 1.0f;
        g.vertices.append(v);
    }
    g.indices = { 0,1,2, 3,4,5 };
    { ::MeshPart p; p.name = QStringLiteral("shown"); p.indexStart = 0; p.indexCount = 3; p.materialIndex = 0; g.parts.append(p); }
    { ::MeshPart p; p.name = QStringLiteral("hidden"); p.indexStart = 3; p.indexCount = 3; p.materialIndex = 1; p.visible = false; g.parts.append(p); }

    const core::Geometry c = poe2adapt::toCore(g);
    check(c.vertices.size() == 6 && c.triangleCount() == 2, "vertex and triangle counts preserved");
    check(c.parts.size() == 2 && !c.parts[1].visible, "part visibility preserved");
    check(c.hasTangent && c.hasUv1 && c.hasColor && c.skinned,
          "attribute flags read from the AUTHORED vertex-format word, not sniffed");
    // Native (x,y,z) -> (x,-z,y): (0,1,2) must become (0,-2,1).
    check(near(c.vertices[0].px, 0) && near(c.vertices[0].py, -2) && near(c.vertices[0].pz, 1),
          "positions rotated native Z-down -> Y-up exactly once");
    check(near(c.vertices[0].nz, 0) && near(c.vertices[0].ny, -1),
          "normals rotated with the positions (+Z -> -Y)");
    check(near(c.bboxMin[1], -2.0f) && near(c.bboxMax[2], 1.0f), "bounds recomputed in the core frame");
    check(c.vertices[3].joints[0] == 3, "u8 joint indices widened to u16 intact");
    check(c.materialNames.size() == 2, "material roster carried");

    printf("\nPOE2 AstSkeleton -> core::Skeleton + core::Clip\n");
    AstSkeleton::Skeleton sk;
    sk.valid = true; sk.clipsDecoded = true;
    {   // child listed first, as PoE2's parser may emit (it resolves parents recursively)
        AstSkeleton::Bone child; child.name = QStringLiteral("child"); child.parent = 1;
        child.bind = core::rm::identity(); child.bind[13] = 3.0f;      // 3 along native Y
        child.inverseBind = core::rm::inverse(child.bind);
        AstSkeleton::Bone root;  root.name = QStringLiteral("root");  root.parent = -1;
        root.bind = core::rm::identity(); root.inverseBind = core::rm::identity();
        sk.bones = { child, root };
    }
    {   AstSkeleton::Clip cl; cl.name = QStringLiteral("walk"); cl.fps = 30;
        AstSkeleton::KeySet ks; ks.nodeId = 0;                          // the child, pre-sort
        ks.posTimes = { 0.0f, 15.0f, 30.0f };                           // FRAME units
        ks.pos = { {{0,0,0}}, {{0,1,0}}, {{0,2,0}} };
        cl.keys.append(ks);
        sk.clips.append(cl);
    }

    QVector<core::Clip> clips;
    const core::Skeleton s = poe2adapt::toCore(sk, &clips);
    check(s.size() == 2 && s.parentsPrecedeChildren(), "joint count preserved, parents sorted first");
    check(s.joints[0].name == QStringLiteral("root"), "root sorted to index 0");
    check(s.joints[1].parent == 0, "child's parent remapped by the sort");
    // Exact, not "one of these": native (0,3,0) through (x,y,z)->(x,-z,y) is (0,0,3). The first
    // draft of this check was an OR because the adapter was wrong and the test was hedging.
    check(near(s.joints[1].restT[0], 0.0f) && near(s.joints[1].restT[1], 0.0f) && near(s.joints[1].restT[2], 3.0f),
          "bind-local translation derived and reframed to exactly (0,0,3)");
    check(clips.size() == 1 && clips[0].tracks.size() == 1, "clip and track carried");
    check(clips[0].tracks[0].joint == 1, "the track was remapped onto the sorted joint index");
    // 30 frames at 30 fps is ONE second — the conversion core exists to make unambiguous.
    check(near(clips[0].tracks[0].tTimes[1], 0.5f) && near(clips[0].tracks[0].tTimes[2], 1.0f),
          "key times converted FRAME units -> seconds");
    check(near(clips[0].duration, 1.0f), "clip duration derived in seconds");
}
