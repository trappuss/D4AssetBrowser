#!/usr/bin/env bash
# Phase-1 conformance: build and run every core self-test and every adapter test, headless.
#
# The adapters compile against the CURRENT game trees rather than copies, so this also proves the
# core types still fit the real parsers. Point D4_SRC / FOX_SRC / POE2_SRC at them.
#
# One binary PER GAME, deliberately: d4 and poe2 both declare `struct ModelGeometry` in the global
# namespace, so a single binary linking both is an ODR violation (it segfaults).
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
QT=${QT:-/usr/include/x86_64-linux-gnu/qt6}
OUT=${1:-/tmp/abconf}
D4_SRC=${D4_SRC:-$ROOT/../d4/src}
FOX_SRC=${FOX_SRC:-$ROOT/../fox/src}
POE2_SRC=${POE2_SRC:-$ROOT/../poe2/src}
mkdir -p "$OUT"; cd "$OUT"
CXX="g++ -std=c++17 -w -fPIC -I$ROOT -I$QT -I$QT/QtCore -I$QT/QtGui"

echo "== core =="
$CXX -c "$ROOT/core/math/RigMath.cpp"        -o rigmath.o
$CXX -c "$ROOT/core/types/Skeleton.cpp"      -o skeleton.o
$CXX -c "$ROOT/core/types/Clip.cpp"          -o clip.o
$CXX -c "$ROOT/core/types/ExportOptions.cpp" -o exportoptions.o
$CXX -c "$ROOT/core/store/BackgroundIndex.cpp" -o bgindex.o
/usr/lib/qt6/libexec/moc "$ROOT/core/store/BackgroundIndex.h" -o moc_bgindex.cpp
$CXX -c moc_bgindex.cpp -o moc_bgindex.o
CORE="rigmath.o skeleton.o clip.o exportoptions.o"

echo "== core self-tests =="
cat > _selftest.cpp <<'EOF'
#include "core/math/RigMath.h"
#include <cstdio>
int main(){ const char* e = core::rm::selfTest();
  printf("  %-62s %s\n", "core::rm::selfTest", *e ? e : "PASS"); return *e ? 1 : 0; }
EOF
$CXX -c _selftest.cpp -o _selftest.o
g++ -o test_core _selftest.o rigmath.o
./test_core

echo "== background index =="
$CXX -c "$ROOT/conformance/tests/test_bgindex.cpp" -o t_bgi.o
g++ -o test_bgindex t_bgi.o bgindex.o moc_bgindex.o -lQt6Core -pthread
QT_QPA_PLATFORM=offscreen ./test_bgindex

for g in d4 fox poe2; do
  case $g in d4) SRC=$D4_SRC; FN=testD4;; fox) SRC=$FOX_SRC; FN=testFox;; poe2) SRC=$POE2_SRC; FN=testPoe2;; esac
  ADAPT=$(ls "$ROOT/games/$g/adapt/"*.cpp)
  echo "== $g adapter =="
  $CXX -I"$SRC" -c "$ADAPT" -o adapt_$g.o
  $CXX -I"$SRC" -c "$ROOT/conformance/tests/test_adapt_$g.cpp" -o t_$g.o
  $CXX -DTEST_FN=$FN -DTEST_NAME="\"$g adapter\"" -c "$ROOT/conformance/tests/runner.cpp" -o run_$g.o
  g++ -o test_$g t_$g.o run_$g.o adapt_$g.o $CORE -lQt6Core -lQt6Gui
  QT_QPA_PLATFORM=offscreen ./test_$g
done
echo
echo "PHASE 1 CONFORMANCE: all suites passed"
echo "OPEN: no suite here parses a real game file — the phase-0 fixtures are still needed for the"
echo "      end-to-end gate (real model through the adapter == real model through the old path)."
