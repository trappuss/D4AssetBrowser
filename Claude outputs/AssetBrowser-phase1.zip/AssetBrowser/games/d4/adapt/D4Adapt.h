#pragma once
#include "core/types/Geometry.h"
#include "core/types/Skeleton.h"

struct ModelGeometry;   // d4/src/model/ModelGeometry.h

// D4 → core. Two real conversions:
//   * per-primitive vertex/index arrays → one shared buffer with the parts as index ranges;
//   * the MIXED-SPACE contract resolved. D4's vertices and inverse-bind matrices are already Y-up
//     (its parser swaps them), but restQ/T/S and the hardpoint transforms are still D4-native
//     Z-up. Core is one frame, so the rest TRS and the hardpoints are swapped here, using the
//     exact mapping D4's own exporter uses (ModelExporter.cpp swapTRS), and a self-test checks
//     that mapping against the independent matrix conjugation.
//
// The inverse-bind matrices are copied byte for byte and that is CORRECT, not a shortcut: D4
// stores column-major for v' = M·v, core stores row-major for v' = v·N, and reading the same 16
// floats the other way gives N = Mᵀ, whose row-vector product is the same transform. The adapter
// test proves it on a real matrix rather than trusting the argument.
namespace d4adapt {

core::Geometry toCore(const ModelGeometry& g);
core::Skeleton skeletonToCore(const ModelGeometry& g);
QVector<core::Hardpoint> hardpointsToCore(const ModelGeometry& g);

// D4-native (Z-up) local TRS → canonical Y-up. Exactly ModelExporter.cpp's swapTRS.
void swapZUpToYUp(const float qIn[4], const float tIn[3], const float sIn[3],
                  float qOut[4], float tOut[3], float sOut[3]);

}  // namespace d4adapt
