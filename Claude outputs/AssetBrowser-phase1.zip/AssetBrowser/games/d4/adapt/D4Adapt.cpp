#include "games/d4/adapt/D4Adapt.h"
#include "model/ModelGeometry.h"
#include <cmath>

namespace d4adapt {

void swapZUpToYUp(const float qIn[4], const float tIn[3], const float sIn[3],
                  float qOut[4], float tOut[3], float sOut[3])
{
    // translation (x, z, -y); quaternion vector part by the same permutation; scale (x, z, y) —
    // a magnitude per axis, so the axes swap but nothing negates.
    tOut[0] = tIn[0]; tOut[1] = tIn[2]; tOut[2] = -tIn[1];
    float x = qIn[0], y = qIn[2], z = -qIn[1], w = qIn[3];
    const float m = std::sqrt(x*x + y*y + z*z + w*w);
    if (m < 1e-9f) { x = y = z = 0.0f; w = 1.0f; } else { x/=m; y/=m; z/=m; w/=m; }
    qOut[0] = x; qOut[1] = y; qOut[2] = z; qOut[3] = w;
    sOut[0] = sIn[0]; sOut[1] = sIn[2]; sOut[2] = sIn[1];
}

static uint8_t toU8(float f) { const int v = int(f * 255.0f + 0.5f); return uint8_t(v < 0 ? 0 : v > 255 ? 255 : v); }

core::Geometry toCore(const ModelGeometry& g)
{
    core::Geometry o;
    o.formatNote    = QStringLiteral("app LOD0");
    o.droppedParts  = g.droppedSubObjects;
    o.droppedVerts  = g.droppedVerts;
    o.skinned       = !g.skeleton.isEmpty();
    o.hasTangent    = false;              // D4 authors no tangent; the viewport derives one (Lengyel)

    int totalV = 0, totalI = 0;
    for (const MeshPrimitive& p : g.primitives) { totalV += p.vertices.size(); totalI += p.indices.size(); }
    o.vertices.reserve(totalV);
    o.indices.reserve(totalI);
    o.parts.reserve(g.primitives.size());

    for (const MeshPrimitive& p : g.primitives) {
        const uint32_t vertexBase = uint32_t(o.vertices.size());
        const uint32_t indexStart = uint32_t(o.indices.size());

        for (const MeshVertex& v : p.vertices) {
            core::Vertex c;
            c.px = v.px; c.py = v.py; c.pz = v.pz;     // already Y-up: the parser swapped them
            c.nx = v.nx; c.ny = v.ny; c.nz = v.nz;
            c.u  = v.u;  c.v  = v.v;
            if (v.hasUv1)  { c.u2 = v.u1; c.v2 = v.v1; o.hasUv1 = true; }
            if (v.hasColor) {
                c.color[0]=toU8(v.cr); c.color[1]=toU8(v.cg); c.color[2]=toU8(v.cb); c.color[3]=toU8(v.ca);
                o.hasColor = true;
            }
            if (v.hasColor1) {
                c.color1[0]=toU8(v.c2r); c.color1[1]=toU8(v.c2g); c.color1[2]=toU8(v.c2b); c.color1[3]=toU8(v.c2a);
                o.hasColor1 = true;
            }
            for (int k = 0; k < 4; ++k) { c.joints[k] = v.joints[k]; c.weights[k] = v.weights[k]; }
            o.vertices.append(c);
        }
        // Indices are primitive-local; rebase them onto the shared buffer.
        for (quint32 i : p.indices) o.indices.append(uint32_t(i) + vertexBase);

        core::Part c;
        c.name          = p.materialName;      // D4 names a primitive by its material; the outliner
                                               // relabels from the roster once that is loaded
        c.indexStart    = indexStart;
        c.indexCount    = uint32_t(p.indices.size());
        c.materialIndex = p.materialIndex;
        c.doubleSided   = p.doubleSided;
        c.nameHash      = p.subObjectHash;
        c.slotHash      = p.slotHash;
        o.parts.append(c);
    }

    o.applyFrame(core::rm::kIdentityFrame);    // no rotation; still computes the bounds
    return o;
}

core::Skeleton skeletonToCore(const ModelGeometry& g)
{
    core::Skeleton o;
    o.nBaseBones = g.nBaseBones;
    o.joints.reserve(g.skeleton.size());
    for (const ModelJoint& j : g.skeleton) {
        core::Joint c;
        c.name     = j.name;
        c.nameHash = j.nameHash;
        c.parent   = j.parent;
        c.cloth    = j.cloth;
        c.chain    = j.chain;
        // Byte-for-byte: D4's column-major M read row-major is Mᵀ, and v·Mᵀ == M·v.
        for (int k = 0; k < 16; ++k) c.inverseBind[k] = j.inverseBind[k];
        float q[4], t[3], s[3];
        swapZUpToYUp(j.restQ.data(), j.restT.data(), j.restS.data(), q, t, s);
        for (int k = 0; k < 4; ++k) c.restQ[k] = q[k];
        for (int k = 0; k < 3; ++k) { c.restT[k] = t[k]; c.restS[k] = s[k]; }
        o.joints.append(c);
    }
    // D4's mergeGeometries already guarantees this; calling it is free when it holds and is the
    // difference between "we believe it holds" and "it holds".
    o.sortParentsFirst();
    return o;
}

QVector<core::Hardpoint> hardpointsToCore(const ModelGeometry& g)
{
    QVector<core::Hardpoint> out;
    out.reserve(g.hardpoints.size());
    for (const ModelHardpoint& h : g.hardpoints) {
        core::Hardpoint c;
        c.name      = h.name;
        c.joint     = h.boneIndex;
        c.jointHash = h.boneHash;
        const float s1[3] = {1,1,1};
        float q[4], t[3], s[3];
        swapZUpToYUp(h.q.data(), h.t.data(), s1, q, t, s);
        for (int k = 0; k < 4; ++k) c.q[k] = q[k];
        for (int k = 0; k < 3; ++k) { c.t[k] = t[k]; c.s[k] = s[k]; }
        // D4's rule: an authored (non-identity) socket is MODEL-space, so the exporter must take
        // inverseBind · socket rather than treating it as bone-local.
        const bool identity = (h.q[0]==0 && h.q[1]==0 && h.q[2]==0 && h.q[3]==1
                               && h.t[0]==0 && h.t[1]==0 && h.t[2]==0);
        c.modelSpace = !identity;
        out.append(c);
    }
    return out;
}

}  // namespace d4adapt
