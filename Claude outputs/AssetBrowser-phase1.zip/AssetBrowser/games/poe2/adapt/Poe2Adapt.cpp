#include "games/poe2/adapt/Poe2Adapt.h"
#include "model/AstSkeleton.h"
#include "model/ModelGeometry.h"

namespace poe2adapt {

using core::rm::Mat4;

// A model-space matrix authored in the native frame, expressed in the canonical frame.
// core::rm::reframe derives the inverse itself — the first draft of this line picked the wrong
// one of two numerically-transposed constants by name and put every bind pose in the wrong place.
static Mat4 reframe(const Mat4& m) { return core::rm::reframe(m, core::rm::kZDownToYUp); }

core::Geometry toCore(const ModelGeometry& g)
{
    core::Geometry o;
    o.sourcePath    = g.sourcePath;
    o.formatVersion = g.formatVersion;
    o.formatNote    = QStringLiteral("%1 v%2, vertex format 0x%3")
                          .arg(g.skinned ? QStringLiteral("smd") : QStringLiteral("fmt"))
                          .arg(g.formatVersion)
                          .arg(g.vertexFormat, 0, 16);
    // AUTHORED flags from the DOLm vertex-format word (docs/FORMATS.md §3), never sniffed from
    // whether a field happens to be non-default.
    o.hasTangent = (g.vertexFormat & 0x10) != 0;
    o.hasUv1     = (g.vertexFormat & 0x01) != 0;
    o.hasColor   = (g.vertexFormat & 0x02) != 0;
    o.skinned    = g.skinned;

    o.vertices.reserve(g.vertices.size());
    for (const MeshVertex& v : g.vertices) {
        core::Vertex c;
        c.px = v.px; c.py = v.py; c.pz = v.pz;
        c.nx = v.nx; c.ny = v.ny; c.nz = v.nz;
        c.tx = v.tx; c.ty = v.ty; c.tz = v.tz; c.tw = v.tw;
        c.u  = v.u;  c.v  = v.v;  c.u2 = v.u2; c.v2 = v.v2;
        for (int k = 0; k < 4; ++k) {
            c.color[k]   = v.color[k];
            c.joints[k]  = uint16_t(v.joints[k]);
            c.weights[k] = v.weights[k];
        }
        o.vertices.append(c);
    }

    o.indices = g.indices;

    o.materialNames.reserve(g.materialPaths.size());
    for (const QString& m : g.materialPaths) o.materialNames << m;

    o.parts.reserve(g.parts.size());
    for (const MeshPart& p : g.parts) {
        core::Part c;
        c.name          = p.name;
        c.indexStart    = p.indexStart;
        c.indexCount    = p.indexCount;
        c.materialIndex = p.materialIndex;
        c.visible       = p.visible;
        c.doubleSided   = true;      // POE2 authors double-sidedness per material, not per part
        o.parts.append(c);
    }

    o.applyFrame(core::rm::kZDownToYUp);   // computes bounds as a side effect
    return o;
}

core::Skeleton toCore(const AstSkeleton::Skeleton& sk, QVector<core::Clip>* clipsOut)
{
    core::Skeleton o;
    o.note = sk.note;
    o.joints.reserve(sk.bones.size());

    for (const AstSkeleton::Bone& b : sk.bones) {
        core::Joint j;
        j.name     = b.name;
        j.nameHash = 0;                       // PoE2 binds clips by index, not by name
        j.parent   = b.parent;
        j.inverseBind = reframe(b.inverseBind);
        o.joints.append(j);
    }

    // Bind-LOCAL TRS from the model-space binds: local = bind · inverse(parentBind).
    for (int i = 0; i < o.joints.size(); ++i) {
        Mat4 local = reframe(sk.bones[i].bind);
        const int p = sk.bones[i].parent;
        if (p >= 0 && p < sk.bones.size())
            local = core::rm::mul(local, core::rm::inverse(reframe(sk.bones[p].bind)));
        float t[3], q[4], s[3];
        core::rm::decomposeTRS(local, t, q, s);
        for (int k = 0; k < 3; ++k) { o.joints[i].restT[k] = t[k]; o.joints[i].restS[k] = s[k]; }
        for (int k = 0; k < 4; ++k)   o.joints[i].restQ[k] = q[k];
    }

    // POE2's parser explicitly does NOT guarantee parents precede children (it resolves them
    // recursively instead), so the family invariant is established here.
    const QVector<int> remap = o.sortParentsFirst();

    if (clipsOut) {
        clipsOut->clear();
        clipsOut->reserve(sk.clips.size());
        for (const AstSkeleton::Clip& c : sk.clips) {
            core::Clip oc;
            oc.name = c.name;
            oc.fps  = float(c.fps > 0 ? c.fps : 30);
            for (const AstSkeleton::KeySet& ks : c.keys) {
                core::Track tr;
                tr.joint = ks.nodeId;
                if (!remap.isEmpty() && ks.nodeId >= 0 && ks.nodeId < remap.size())
                    tr.joint = remap[ks.nodeId];
                // Frame units → seconds, once, here. This is the conversion that made the core
                // clip type worth defining in seconds: POE2 is the only one that stores frames.
                for (float ft : ks.posTimes)   tr.tTimes.append(ft / oc.fps);
                for (float ft : ks.rotTimes)   tr.qTimes.append(ft / oc.fps);
                for (float ft : ks.scaleTimes) tr.sTimes.append(ft / oc.fps);
                for (const auto& v : ks.pos)   tr.t.append(v);
                for (const auto& v : ks.rot)   tr.q.append(core::rm::Quat{v[0], v[1], v[2], v[3]});
                for (const auto& v : ks.scale) tr.s.append(v);
                if (!tr.isEmpty()) oc.tracks.append(tr);
            }
            oc.recomputeDuration();
            clipsOut->append(oc);
        }
    }
    return o;
}

}  // namespace poe2adapt
