#pragma once
#include "core/types/Clip.h"
#include "core/types/Geometry.h"
#include "core/types/Skeleton.h"

struct ModelGeometry;                       // poe2/src/model/ModelGeometry.h
namespace AstSkeleton { struct Skeleton; }  // poe2/src/model/AstSkeleton.h

// PoE2 → core. The smallest of the three adapters: POE2's contract IS the shape core took, so
// this is a copy plus three real conversions —
//   * the native Z-down → Y-up rotation, applied ONCE here instead of separately in the viewport
//     and the exporter (which is how those two can disagree);
//   * u8 joint indices widened to u16 (POE2 cannot represent a rig past 256 bones today);
//   * clip key times divided by fps, because POE2 stores them in FRAME units.
namespace poe2adapt {

core::Geometry toCore(const ModelGeometry& g);

// Bones → core::Skeleton (parents sorted first) and clips → core::Clip, in one call because the
// clip tracks are bound by bone INDEX and must be remapped by the same sort.
core::Skeleton toCore(const AstSkeleton::Skeleton& sk, QVector<core::Clip>* clipsOut);

}  // namespace poe2adapt
