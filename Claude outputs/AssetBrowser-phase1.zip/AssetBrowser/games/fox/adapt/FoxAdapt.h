#pragma once
#include "core/types/Geometry.h"
#include "core/types/Skeleton.h"

#include <QVector>
namespace fox { class FmdlFile; struct FmdlMesh; struct FmdlMeshGroup; struct FmdlMaterialInstance; struct FmdlBone; }

// Fox Engine → core. THE BIG ONE: Fox has no engine-neutral geometry type at all. Its parser
// output (fox::FmdlFile) goes straight to GPU-shaped uploads and its exporter consumes FmdlFile
// directly, so this file is the piece of genuinely new code the whole extraction turns on
// (core-audit/tabs-store.md §7.2). Four real conversions:
//
//   1. SoA → AoS. FmdlMesh keeps positions/normals/uv0/tangents/boneIndices/boneWeights as six
//      parallel arrays; core keeps one interleaved Vertex. (Fox's own viewport already flattens
//      exactly this way in ModelLoader::buildUploads, so the shape is proven, not invented.)
//   2. Palette-relative → global joints. A mesh's boneIndices are u8 indices into ITS OWN
//      `palette`, which maps to skeleton indices. Copying them without resolving would skin every
//      mesh to the first 256 bones of the rig — silently, and only visibly wrong in motion.
//   3. Per-mesh index lists → one shared buffer, u16 widened to u32 and rebased.
//   4. The mesh-group TREE preserved (core::PartGroup), including the shipped-hidden flag: 213 of
//      Survive's 1,277 character groups ship invisible and a viewer that ignores it stacks every
//      alternative pouch on one model.
//
// Fox is already Y-up, so the frame conversion is the identity — recorded explicitly rather than
// left out, so the next reader can see that it was decided and not forgotten.
// The conversions take the parser's PUBLIC sub-structs rather than the FmdlFile object. Two
// reasons, and the second is the one that matters: the adapter genuinely needs only these, and a
// test can build them directly — FmdlFile's fields are private and fillable only by parse(), so a
// whole-object signature would make this, the largest new piece of code in the extraction, the one
// piece with no test until a real .fmdl fixture exists.
namespace foxadapt {

core::Geometry toCore(const QVector<fox::FmdlMesh>& meshes,
                      const QVector<fox::FmdlMeshGroup>& groups,
                      const QVector<fox::FmdlMaterialInstance>& materials,
                      float version);
core::Skeleton skeletonToCore(const QVector<fox::FmdlBone>& bones);

// Convenience wrappers for the real parse path.
core::Geometry toCore(const fox::FmdlFile& m);
core::Skeleton skeletonToCore(const fox::FmdlFile& m);

}  // namespace foxadapt
