#include "games/fox/adapt/FoxAdapt.h"
#include "fox/FmdlFile.h"
#include <QSet>
#include <cmath>

namespace foxadapt {

core::Geometry toCore(const QVector<fox::FmdlMesh>& meshes,
                      const QVector<fox::FmdlMeshGroup>& groups,
                      const QVector<fox::FmdlMaterialInstance>& mats,
                      float version)
{
    core::Geometry o;
    o.formatNote = QStringLiteral("fmdl v%1").arg(double(version), 0, 'f', 2);

    // ── the group tree ──────────────────────────────────────────────────────────────────────
    o.groups.reserve(groups.size());
    for (const fox::FmdlMeshGroup& g : groups) {
        core::PartGroup pg;
        pg.name     = g.name;
        pg.parent   = g.parentIndex;
        pg.visible  = g.visible;
        pg.nameHash = g.nameHash32;
        o.groups.append(pg);
    }
    // A group's visibility is inherited: a child of a shipped-hidden group is hidden too. Resolved
    // here, once, so no consumer has to walk the tree to answer "is this part shown by default".
    auto groupShown = [&](int gi) {
        int guard = 0;
        while (gi >= 0 && gi < o.groups.size() && guard++ < 256) {
            if (!o.groups[gi].visible) return false;
            gi = o.groups[gi].parent;
        }
        return true;
    };

    // ── meshes → parts on one shared buffer ─────────────────────────────────────────────────
    int totalV = 0, totalI = 0;
    for (const fox::FmdlMesh& fm : meshes) { totalV += fm.positions.size() / 3; totalI += fm.triangles.size(); }
    o.vertices.reserve(totalV);
    o.indices.reserve(totalI);
    o.parts.reserve(meshes.size());

    o.materialNames.reserve(mats.size());
    for (const fox::FmdlMaterialInstance& mi : mats) o.materialNames << mi.name;

    for (const fox::FmdlMesh& fm : meshes) {
        const int nv = fm.positions.size() / 3;
        if (nv <= 0 || fm.triangles.isEmpty()) { ++o.droppedParts; continue; }

        const bool hasNrm  = fm.normals.size()  >= nv * 3;
        const bool hasUv   = fm.uv0.size()      >= nv * 2;
        const bool hasTan  = fm.tangents.size() >= nv * 4;
        const bool hasSkin = fm.boneIndices.size() >= nv * 4 && fm.boneWeights.size() >= nv * 4;
        if (hasTan)  o.hasTangent = true;
        if (hasSkin) o.skinned    = true;

        const uint32_t vertexBase = uint32_t(o.vertices.size());
        const uint32_t indexStart = uint32_t(o.indices.size());

        for (int i = 0; i < nv; ++i) {
            core::Vertex c;
            c.px = fm.positions[i*3+0]; c.py = fm.positions[i*3+1]; c.pz = fm.positions[i*3+2];
            if (hasNrm) { c.nx = fm.normals[i*3+0]; c.ny = fm.normals[i*3+1]; c.nz = fm.normals[i*3+2]; }
            if (hasUv)  { c.u  = fm.uv0[i*2+0];     c.v  = fm.uv0[i*2+1]; }
            if (hasTan) { c.tx = fm.tangents[i*4+0]; c.ty = fm.tangents[i*4+1];
                          c.tz = fm.tangents[i*4+2]; c.tw = fm.tangents[i*4+3] >= 0 ? 1.0f : -1.0f; }
            if (hasSkin) {
                for (int k = 0; k < 4; ++k) {
                    // Conversion 2: palette-relative → global skeleton index.
                    const int pi = int(fm.boneIndices[i*4+k]);
                    c.joints[k]  = (pi >= 0 && pi < fm.palette.size()) ? fm.palette[pi] : 0;
                    c.weights[k] = fm.boneWeights[i*4+k];
                }
            }
            o.vertices.append(c);
        }

        for (quint16 idx : fm.triangles) o.indices.append(uint32_t(idx) + vertexBase);

        core::Part p;
        p.group         = fm.meshGroupIndex;
        p.name          = (fm.meshGroupIndex >= 0 && fm.meshGroupIndex < groups.size())
                              ? groups[fm.meshGroupIndex].name
                              : QStringLiteral("mesh%1").arg(o.parts.size());
        p.nameHash      = (fm.meshGroupIndex >= 0 && fm.meshGroupIndex < groups.size())
                              ? groups[fm.meshGroupIndex].nameHash32 : 0;
        p.indexStart    = indexStart;
        p.indexCount    = uint32_t(fm.triangles.size());
        p.materialIndex = fm.materialInstanceIndex;
        p.visible       = groupShown(fm.meshGroupIndex);
        p.doubleSided   = true;            // Fox draws and exports every surface two-sided
        o.parts.append(p);
    }

    o.applyFrame(core::rm::kIdentityFrame);   // Fox is already Y-up; still computes the bounds
    return o;
}

core::Skeleton skeletonToCore(const QVector<fox::FmdlBone>& bones)
{
    core::Skeleton o;
    o.joints.reserve(bones.size());

    for (const fox::FmdlBone& b : bones) {
        core::Joint j;
        j.name     = b.name;
        j.nameHash = b.hash32;
        j.parent   = b.parentIndex;
        // Fox's bind pose is TRANSLATION-ONLY: localPos is the bind-local translation and there is
        // no authored rotation or scale, so restQ stays identity and restS stays 1. Inventing a
        // rotation here would be a guess; the exporter derives the inverse bind the same way Fox's
        // own does — translate(-worldPos).
        for (int k = 0; k < 3; ++k) j.restT[k] = b.localPos[k];
        j.inverseBind = core::rm::identity();
        j.inverseBind[12] = -b.worldPos[0];
        j.inverseBind[13] = -b.worldPos[1];
        j.inverseBind[14] = -b.worldPos[2];
        o.joints.append(j);
    }
    o.sortParentsFirst();   // FmdlFile documents parents-precede-children; this makes it true
    return o;
}

core::Geometry toCore(const fox::FmdlFile& m)
{
    return toCore(m.meshes(), m.meshGroups(), m.materials(), m.version());
}

core::Skeleton skeletonToCore(const fox::FmdlFile& m)
{
    return skeletonToCore(m.bones());
}

}  // namespace foxadapt
