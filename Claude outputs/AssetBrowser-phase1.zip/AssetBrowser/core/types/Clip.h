#pragma once
#include "core/math/RigMath.h"
#include <QString>
#include <QVector>

// ── The engine-neutral animation clip ───────────────────────────────────────────────────────────
// The three decoders are unrelated (geometry-export.md §3), but all three end up as per-joint TRS
// keys at the glTF boundary, so that is what core carries:
//   D4   AnimParser::DecodedAnim — DENSE, one key per frame per bone, bound by NAME HASH
//   POE2 AstSkeleton::Clip       — SPARSE per channel, times in FRAME UNITS, bound by bone INDEX
//   FOX  glb::GlbAnimation       — no clip type at all: a pose CALLBACK the exporter bakes
//
// Core is the sparse form in SECONDS bound by joint index: POE2 fits natively (÷ fps once at
// ingest — its keys are in frame units, which is the detail that made this worth stating), D4 fits
// as dense (times = i/fps, hash→index resolved at ingest), FOX fits as baked-dense.
namespace core {

struct Track {
    int joint = -1;
    QVector<float> tTimes;  QVector<std::array<float,3>> t;    // seconds
    QVector<float> qTimes;  QVector<rm::Quat>            q;    // xyzw
    QVector<float> sTimes;  QVector<std::array<float,3>> s;    // FOX never authors scale

    bool isEmpty() const { return t.isEmpty() && q.isEmpty() && s.isEmpty(); }
    // A track equal to the joint's rest pose within eps carries no information; FOX's exporter
    // drops these and it is the single biggest saving on a long clip. Core exposes the test so
    // every exporter can make the same choice.
    bool isConstant(const float restT[3], const rm::Quat& restQ, const float restS[3], float eps = 1e-6f) const;
};

struct Clip {
    QString name;
    float   fps = 30;
    float   duration = 0;        // seconds; derived at ingest, never re-derived downstream
    QVector<Track> tracks;
    bool    baked = false;       // [FOX] sampled from a solver, so dense by construction

    bool isEmpty() const { return tracks.isEmpty(); }
    int  frameCount() const { return fps > 0 ? int(duration * fps + 0.5f) : 0; }
    void recomputeDuration()
    {
        duration = 0;
        for (const Track& tr : tracks)
            for (const QVector<float>* a : { &tr.tTimes, &tr.qTimes, &tr.sTimes })
                for (float v : *a) if (v > duration) duration = v;
    }
};

}  // namespace core
