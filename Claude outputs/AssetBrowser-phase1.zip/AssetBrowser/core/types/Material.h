#pragma once
#include <QImage>
#include <QString>

// ── The engine-neutral material ─────────────────────────────────────────────────────────────────
// The glTF-facing subset all three agree on, plus POE2's extensions (geometry-export.md §4).
// Everything viewport-only — D4's dye/fur/FX/detail/hair/eye, FOX's SRM/TRM/layer/glass/MTM,
// POE2's subsurface/fur — stays in the plugin behind `engine`, because putting forty
// engine-specific fields in core is how core stops being core.
namespace core {

struct TextureImage {
    QImage  image;              // decoded RGBA
    QString sourcePath;         // [FOX *_Source] [POE2 .mat role path] [D4 texName/SNO]
    bool    srgb = true;
    bool    lossyOk = false;    // [FOX] JPEG permitted (opaque base maps only)

    bool isNull() const { return image.isNull(); }
};

struct Material {
    QString name;
    bool    doubleSided = false;

    enum AlphaMode { Opaque, Mask, Blend, Additive };   // glTF has no Additive → exporters write BLEND
    AlphaMode alphaMode = Opaque;
    float     alphaCutoff = 0.5f;                       // D4 0.35, FOX 0.35, POE2 0.5

    float metalFactor = 0.0f;
    float roughFactor = 1.0f;

    TextureImage baseColor;
    TextureImage normal;
    TextureImage orm;           // R = occlusion, G = roughness, B = metalness
    TextureImage emissive;
    bool  ormHasOcclusion = false;   // FOX's SRM has no AO channel — writing one would invent data
    float occlusionStrength = 1.0f;

    float emissiveFactor[3] = {1,1,1};
    float emissiveStrength = 1.0f;

    // KHR extensions POE2 authors today; an exporter emits each only when set.
    TextureImage specularColor;
    bool  dielectricSpec = false;    // KHR_materials_specular
    float transmission = 0.0f;       // KHR_materials_transmission

    // The SOURCE's normal-map convention, so the conversion happens ONCE in core instead of under
    // three different names (D4 flipNormalGreen, FOX normalsGreenDown, POE2 reconstructNormalZ).
    bool normalGreenDown = false;
    bool normalNeedsZ    = false;

    // Opaque handle to the plugin's own material record, for viewport extensions. Core never
    // dereferences it; a plugin static_casts it back.
    const void* engine = nullptr;
};

}  // namespace core
