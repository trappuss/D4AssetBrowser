#pragma once
#include "core/store/IGameStore.h"
#include "core/types/Asset.h"
#include <QString>
#include <QVector>
#include <QWidget>
#include <functional>

// ── What a game contributes to the shell ────────────────────────────────────────────────────────
// The shell owns the menu bar, the export menu, the status bar, hotkeys, the log, the settings
// skeleton, geometry/tab persistence and the index indicator (core-audit/app-shell.md §2.5). The
// three MainWindows hardcode their tab lists today — that list is the first thing this replaces.
namespace core {

class BrowserTab;

struct TabSpec {
    QString title;              // tab-bar label — may be renamed without breaking anything
    QString stableId;           // "textures" — what session/tab and Ctrl+N persist (NEVER the title:
                                // FOX stores the title today, so renaming a tab drops the restore)
    bool    lazy = false;       // [D4 LazyTab] construct on first show
    std::function<BrowserTab*(QWidget* parent)> make;
};

struct IndexSpec {              // one File ▸ Index row + its status indicator   [D4 IndexDesc]
    QString name;
    QString what;               // one line: what it makes possible
    std::function<bool()> ready;
    std::function<bool()> building;
    std::function<void()> start;
    std::function<void()> reset;
    bool hasPercent = false;
};

struct HelpEntry {
    QString label;
    QString tooltip;
    std::function<void()> run;
};

struct SettingsPage {
    QString title;
    // Template §16 order: setup 0 · presentation 1 · per-area 2 · disk 3 · keys 4 · upkeep 5 ·
    // reference 6 · experimental 7. Core owns 0–6's generic halves; a plugin inserts its own.
    int     order = 2;
    std::function<QWidget*(QWidget* parent)> build;
    std::function<void()> apply;        // on OK
    std::function<void()> revert;       // on Cancel, for pages that write live
    QStringList resetGroups;            // QSettings groups cleared BY REMOVAL (§3.10)
    QStringList keepPrefixes;           // user-authored subtrees a reset must not touch
};

struct CacheDef {                       // [FOX cachemaint::defs()]
    QString label, subdir, glob, tooltip;
};

class AppPlugin {
public:
    virtual ~AppPlugin() = default;

    virtual QString productName() const = 0;        // window title, About, log stem, INI name
    virtual QString version() const = 0;
    virtual IGameStore* store() = 0;

    virtual QVector<TabSpec>      tabs() = 0;
    virtual QVector<IndexSpec>    indexRoster() { return {}; }
    virtual QVector<SettingsPage> settingsPages() { return {}; }
    virtual QVector<HelpEntry>    helpEntries() { return {}; }
    virtual QVector<CacheDef>     cacheDefs() { return {}; }

    // Is the game folder configured? Drives the first-run page.
    virtual bool isConfigured() = 0;
    virtual QWidget* firstRunPage(QWidget* parent) { return nullptr; }
    virtual void reload(std::function<void(bool ok, const QString& status)> done) = 0;
    virtual QString diagnosticInfo() { return {}; }

    // ── search vocabulary the plugin owns ───────────────────────────────────────────────────
    // "Is this search term an id?" is engine-specific: D4 = a run of digits (SNO), FOX = a 16-hex
    // PathFileNameCode, POE2 = decimal or 0x-hex MurmurHash. The one matcher stays in core; only
    // this predicate varies (app-shell.md §1.1).
    virtual bool isIdTerm(const QString& term) const { return false; }
    virtual AssetId idFromTerm(const QString& term) const { return {}; }

    // Menu nouns, so core's MenuText can say "Copy SNO" in D4 and "Copy hash" in FOX without
    // either word living in core.
    struct Nouns {
        QString id = QStringLiteral("id");          // "SNO" / "hash"
        QString collection;                          // "collection" — empty ⇒ the action is omitted
        QString modelExt = QStringLiteral("model");
    };
    virtual Nouns nouns() const { return {}; }

    // Startup self-tests this plugin contributes to the conformance runner.
    virtual QVector<std::function<QString()>> selfTests() { return {}; }
};

}  // namespace core
