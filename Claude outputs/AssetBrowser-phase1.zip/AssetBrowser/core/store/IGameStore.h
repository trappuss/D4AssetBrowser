#pragma once
#include "core/types/Asset.h"
#include "core/types/Clip.h"
#include "core/types/Geometry.h"
#include "core/types/Material.h"
#include "core/types/Skeleton.h"
#include <QImage>
#include <QPixmap>
#include <QString>
#include <QVector>
#include <functional>
#include <memory>

// ── The one seam between the generic UI and a game ──────────────────────────────────────────────
//
// Every method below is the generalisation of a function that EXISTS in all three tools today; the
// per-project mapping is the table in core-audit/tabs-store.md §7.1. Nothing here is speculative:
// POE2's AssetStore is already almost exactly this shape, which is why its BulkExtractor needs only
// the store and not the tab.
//
// THREADING — stated because the three projects disagree today and the core ModelsTab loads on a
// worker thread for every game (plan §8.4, settled):
//   * open / fingerprint / buildSecondaryIndexes : called once, on a worker; not re-entrant.
//   * read / loadModel / loadSkeleton / resolveMaterials / loadTexture : MUST be thread-safe —
//     the model loader and the bulk workers call them concurrently.
//   * rowCount / row / searchBlob / tagGroups / hasTag / gameIcon : GUI thread only (D4's
//     SnoIndex name caches and FOX's lazily-rebuilt ModelTags are not safe otherwise).
// A plugin that cannot honour the thread-safe set says so with isThreadSafe() == false and the
// core loader serialises it rather than corrupting an index quietly.
namespace core {

using ProgressFn = std::function<void(const QString&)>;

struct TextureInfo {
    int width = 0, height = 0, mips = 1, slices = 1;
    QString format;             // "BC7", "ETC2", "DXT5"…
    QString note;               // e.g. "placeholder 128² substituted"
};

struct Attachment {
    QString label;              // "coat", "feathers"
    QString parentBone;
    AssetId mesh;               // resolved drawable, invalid when it could not be resolved
    QString unresolvedNote;     // why, when mesh is invalid — never silently dropped
};

struct Use {
    AssetId id;
    QString role;               // "albedo", "material", "actor"
    QString label;
};

// RAII cache that lives only for one bulk run. [D4 MaterialDecode::TextureCacheScope]
// [FOX extract::blobcache::Scope] [POE2 none — returns null, which is a valid answer]
class RunCache { public: virtual ~RunCache() = default; };

class IGameStore {
public:
    virtual ~IGameStore() = default;

    // ── identity ────────────────────────────────────────────────────────────────────────────
    virtual QString gameName() const = 0;           // "Diablo IV", "Fox Engine", "Path of Exile 2"
    virtual bool    isThreadSafe() const { return true; }

    // ── lifecycle ───────────────────────────────────────────────────────────────────────────
    virtual bool    open(const QString& dataDir, QString* error, ProgressFn progress = {}) = 0;
    virtual bool    isOpen() const = 0;
    // Signs every derived cache. Must change when the game build, the community data, or the
    // archive set changes: D4 folds in the TACT key set, FOX every archive's mtime, POE2 the index
    // file's size+mtime.
    virtual QString fingerprint() const = 0;
    virtual void    buildSecondaryIndexes(ProgressFn progress = {}) {}

    // ── rows ────────────────────────────────────────────────────────────────────────────────
    virtual QVector<QString> kinds() const = 0;     // which list tabs exist, in tab order
    virtual int      rowCount(const QString& kind) const = 0;
    virtual AssetRow row(const QString& kind, int i) const = 0;
    virtual QString  searchBlob(const AssetId&) const { return {}; }   // the '#' metadata haystack
    virtual QVector<TagGroup> tagGroups(const QString& kind) const { return {}; }
    virtual bool     hasTag(const AssetId&, const QString& tag) const { return false; }

    // ── bytes ───────────────────────────────────────────────────────────────────────────────
    // `part` selects among several blobs for one id: D4 needs "meta" and "payload"; the others
    // ignore it. A plugin lists what it accepts in parts().
    virtual QByteArray read(const AssetId&, const QString& part, QString* error) = 0;
    virtual QVector<QString> parts() const { return { QString() }; }
    virtual QStringList dependencyFiles(const AssetId&) { return {}; }

    // ── models ──────────────────────────────────────────────────────────────────────────────
    virtual bool loadModel(const AssetId&, Geometry&, QString* error) = 0;
    virtual Skeleton loadSkeleton(const AssetId&, const Geometry&, bool decodeClips, QVector<Clip>* clipsOut) = 0;
    virtual QVector<Material> resolveMaterials(const AssetId&, const Geometry&, bool decodeImages) = 0;
    virtual QVector<Hardpoint> hardpoints(const AssetId&, const Skeleton&) { return {}; }
    virtual QVector<Attachment> attachments(const AssetId&) { return {}; }

    // ── textures ────────────────────────────────────────────────────────────────────────────
    virtual QImage loadTexture(const AssetId&, TextureInfo* info, QString* error) = 0;

    // ── links and icons ─────────────────────────────────────────────────────────────────────
    virtual QVector<Use> usedBy(const AssetId&) { return {}; }
    virtual QVector<Use> uses(const AssetId&)   { return {}; }
    virtual QPixmap gameIcon(const AssetId&, int px) { return {}; }
    virtual QVector<AssetId> variants(const AssetId&) { return {}; }

    // ── run-scoped cache ────────────────────────────────────────────────────────────────────
    virtual std::unique_ptr<RunCache> beginRunCache() { return nullptr; }
};

}  // namespace core
